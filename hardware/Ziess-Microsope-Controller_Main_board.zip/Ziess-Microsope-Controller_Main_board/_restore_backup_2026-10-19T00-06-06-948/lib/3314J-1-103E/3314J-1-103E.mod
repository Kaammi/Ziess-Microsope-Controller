PCBNEW-LibModule-V1  2026-05-30 14:46:38
# encoding utf-8
Units mm
$INDEX
3314J-1
$EndINDEX
$MODULE 3314J-1
Po 0 0 0 15 6a1aea3e 00000000 ~~
Li 3314J-1
Cd 3314J-1
Kw Resistor
Sc 0
At SMD
AR 
Op 0 0 0
T0 -0.352 -0.094 1.27 1.27 0 0.254 N V 21 N "R**"
T1 -0.352 -0.094 1.27 1.27 0 0.254 N I 21 N "3314J-1"
DS -2.5 -2.5 2.5 -2.5 0.2 24
DS 2.5 -2.5 2.5 2.5 0.2 24
DS 2.5 2.5 -2.5 2.5 0.2 24
DS -2.5 2.5 -2.5 -2.5 0.2 24
DS -2.5 -2.5 -2.5 2.5 0.2 21
DS 2.5 -2.5 2.5 2.5 0.2 21
DS -2.5 2.5 -1.3 2.5 0.2 21
DS 2.5 2.5 1.3 2.5 0.2 21
DC -1.161 -3.257 -1.183 -3.257 0.254 21
$PAD
Po -1.15 -2
Sh "1" R 1.3 2 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 2
Sh "2" R 2 2 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.15 -2
Sh "3" R 1.3 2 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE 3314J-1
$EndLIBRARY
